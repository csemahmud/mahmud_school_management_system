-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2017 at 05:49 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_mahmud_school_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `admin_id` int(2) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_email_address` varchar(100) NOT NULL,
  `admin_password` varchar(32) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email_address`, `admin_password`) VALUES
(1, 'Mahmudul Hasan Khan', 'cse.mahmudul@gmail.com', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'বেকার Engineer', 'cse.mahmud@yahoo.com', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admission`
--

CREATE TABLE IF NOT EXISTS `tbl_admission` (
  `admission_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `middle_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) NOT NULL,
  `class` int(2) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `gender` varchar(1) NOT NULL COMMENT 'gender = m : male; gender = f : female;',
  `religion` varchar(1) NOT NULL COMMENT 'religion = i : Islam; religion = h :  Hindu; religion = c : Christian; religion = b : Buddhist; religion = o : other;',
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `student_image` varchar(100) DEFAULT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`admission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_admission`
--

INSERT INTO `tbl_admission` (`admission_id`, `first_name`, `middle_name`, `last_name`, `class`, `father_name`, `mother_name`, `birth_date`, `gender`, `religion`, `phone`, `email`, `student_image`, `address`) VALUES
(17, 'Shihab', '', 'Uddin', 1, 'Nazim   Uddin', 'Momtaz   Begum', '2004-12-31', 'm', 'i', '01916931410', 'shihab@mail.com', 'uploads/student_images/Unni_Passport_size_photo_in_Colour_dress.jpg', 'Dhaka'),
(18, 'Samia', '', 'Zahan', 1, 'Harun   -  Or - Rashid', 'Sanjida   Akhter', '2004-12-31', 'f', 'i', '01916931410', 'samia@mail.com', 'uploads/student_images/v3z6.jpg', 'Dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assign_course`
--

CREATE TABLE IF NOT EXISTS `tbl_assign_course` (
  `assign_course_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(6) NOT NULL,
  `course` varchar(3) NOT NULL,
  `class` int(2) NOT NULL,
  `term` tinyint(1) NOT NULL COMMENT 'term = 1 : Half - Yearly;   term = 2 : Final;',
  `year` year(4) NOT NULL,
  `assign_status` tinyint(2) NOT NULL DEFAULT '1' COMMENT 'assign_status = 0 : Not   Assigned;   assign_status = 1 : Assigned;',
  PRIMARY KEY (`assign_course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `tbl_assign_course`
--

INSERT INTO `tbl_assign_course` (`assign_course_id`, `teacher_id`, `course`, `class`, `term`, `year`, `assign_status`) VALUES
(19, 15, 'b', 1, 1, 2014, 0),
(20, 15, 'is', 1, 1, 2014, 0),
(21, 15, 'a', 1, 1, 2014, 0),
(22, 17, 'e', 1, 1, 2014, 0),
(23, 16, 'he', 1, 1, 2014, 0),
(24, 17, 'hs', 1, 1, 2014, 0),
(25, 15, 'b', 5, 1, 2014, 0),
(26, 15, 'is', 5, 1, 2014, 0),
(27, 16, 'he', 5, 1, 2014, 0),
(28, 15, 'b', 1, 2, 2014, 1),
(29, 15, 'is', 1, 2, 2014, 1),
(30, 15, 'a', 1, 2, 2014, 1),
(31, 17, 'e', 1, 2, 2014, 1),
(32, 16, 'he', 1, 2, 2014, 1),
(33, 17, 'hs', 1, 2, 2014, 1),
(34, 15, 'b', 5, 2, 2014, 1),
(35, 15, 'is', 5, 2, 2014, 1),
(36, 16, 'he', 5, 2, 2014, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_experience_teacher`
--

CREATE TABLE IF NOT EXISTS `tbl_experience_teacher` (
  `experience_id` int(7) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(6) NOT NULL,
  `institute` varchar(200) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `years` int(3) NOT NULL,
  PRIMARY KEY (`experience_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_experience_teacher`
--

INSERT INTO `tbl_experience_teacher` (`experience_id`, `teacher_id`, `institute`, `designation`, `years`) VALUES
(6, 15, 'Udayan   Uchcha   Madhyamik   Bidydlaya', 'Asst.   Professor', 2),
(7, 15, 'University   Laboratory   School   &   College', 'Lecturer', 3),
(8, 17, 'University   Laboratory   School   &   College', 'Lecturer', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mark`
--

CREATE TABLE IF NOT EXISTS `tbl_mark` (
  `mark_id` int(11) NOT NULL AUTO_INCREMENT,
  `year` year(4) NOT NULL,
  `term` tinyint(1) NOT NULL COMMENT 'term = 1 : Half - Yearly;   term = 2 : Final;',
  `class` int(2) NOT NULL,
  `course` varchar(3) NOT NULL,
  `student_id` int(11) NOT NULL,
  `first_class_test` double NOT NULL,
  `second_class_test` double NOT NULL,
  `third_class_test` double NOT NULL,
  `main_exam` double NOT NULL,
  `publication_status` varchar(1) NOT NULL DEFAULT 's' COMMENT 'publication_status = g : Mark   Given;   publication_status = s :   Mark  Submitted;   publication_status = a : Mark   Accepted;   publication_status  =  d : Mark   Denied;',
  PRIMARY KEY (`mark_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `tbl_mark`
--

INSERT INTO `tbl_mark` (`mark_id`, `year`, `term`, `class`, `course`, `student_id`, `first_class_test`, `second_class_test`, `third_class_test`, `main_exam`, `publication_status`) VALUES
(31, 2014, 1, 1, 'b', 10, 20, 20, 20, 100, 'a'),
(32, 2014, 1, 1, 'b', 11, 10, 10, 10, 70, 'a'),
(33, 2014, 1, 1, 'b', 12, 10, 10, 10, 70, 'a'),
(34, 2014, 1, 1, 'b', 13, 10, 10, 10, 75, 'a'),
(35, 2014, 1, 1, 'b', 14, 10, 10, 10, 75, 'a'),
(36, 2014, 1, 1, 'b', 15, 10, 10, 10, 70, 'a'),
(37, 2014, 1, 1, 'is', 10, 20, 20, 20, 100, 'a'),
(38, 2014, 1, 1, 'is', 11, 15, 15, 15, 85, 'a'),
(39, 2014, 1, 1, 'is', 13, 15, 15, 15, 75, 'a'),
(40, 2014, 1, 1, 'is', 14, 15, 15, 15, 75, 'a'),
(41, 2014, 1, 1, 'a', 10, 20, 20, 20, 100, 'a'),
(42, 2014, 1, 1, 'a', 11, 10, 10, 10, 80, 'a'),
(43, 2014, 1, 1, 'a', 12, 10, 10, 10, 70, 'a'),
(44, 2014, 1, 5, 'b', 16, 10, 10, 10, 70, 's'),
(45, 2014, 1, 5, 'b', 17, 10, 10, 10, 85, 's'),
(46, 2014, 1, 5, 'is', 16, 10, 10, 10, 70, 's'),
(47, 2014, 1, 5, 'is', 17, 10, 10, 10, 95, 's'),
(48, 2014, 1, 1, 'he', 13, 10, 10, 10, 95, 'a'),
(49, 2014, 1, 1, 'he', 14, 10, 10, 10, 70, 'a'),
(50, 2014, 1, 1, 'he', 15, 10, 10, 10, 80, 'a'),
(51, 2014, 1, 5, 'he', 16, 15, 15, 15, 95, 's'),
(52, 2014, 1, 5, 'he', 17, 15, 15, 15, 75, 's'),
(53, 2014, 1, 1, 'e', 10, 20, 20, 20, 100, 'a'),
(54, 2014, 1, 1, 'e', 11, 10, 10, 10, 90, 'a'),
(55, 2014, 1, 1, 'e', 12, 10, 10, 10, 70, 'a'),
(56, 2014, 1, 1, 'e', 13, 10, 10, 10, 80, 'a'),
(57, 2014, 1, 1, 'e', 14, 10, 10, 10, 90, 'a'),
(58, 2014, 1, 1, 'e', 15, 5, 5, 0, 15, 'a'),
(59, 2014, 1, 1, 'hs', 12, 10, 10, 10, 90, 'a'),
(60, 2014, 1, 1, 'hs', 15, 10, 10, 10, 75, 'a');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notice`
--

CREATE TABLE IF NOT EXISTS `tbl_notice` (
  `notice_id` int(6) NOT NULL AUTO_INCREMENT,
  `notice_title` varchar(100) NOT NULL,
  `notice_description` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL COMMENT 'publication_status = 0 : Notice  Unpublished   and   publication_status = 1 : Notice   Published',
  `created_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_notice`
--

INSERT INTO `tbl_notice` (`notice_id`, `notice_title`, `notice_description`, `publication_status`, `created_date_time`) VALUES
(3, 'Tution   Fee', '<div>&nbsp;<span style="font-size: 10pt;">All &nbsp; the &nbsp;guardians &nbsp; are &nbsp; requested &nbsp; to &nbsp;pay &nbsp; tution &nbsp; fee &nbsp; before &nbsp; 10-07-2014 &nbsp; .</span></div>', 1, '2014-08-26 15:37:13'),
(4, 'Vacation   for   Eid - Ul - Fitr', 'The &nbsp; Learn &nbsp; Center &nbsp; Institute &nbsp; will &nbsp; be &nbsp; closed &nbsp; from &nbsp;17-07-2014 &nbsp; to &nbsp; 2-08-2014 &nbsp; for &nbsp; holy &nbsp; Ramadan &nbsp; and &nbsp; Eid - Ul - Fitr &nbsp; .', 1, '2014-08-26 15:42:13'),
(5, 'Parents   Meeting', '<div>Parents &nbsp; meeting &nbsp; will &nbsp;be &nbsp;held &nbsp; on &nbsp; 15-09-2014 &nbsp; .</div>', 1, '2014-08-27 05:05:09'),
(6, 'Vacation   for   Eid - Ul - Azha', '<div>The &nbsp; Learn &nbsp; Center &nbsp; Institute &nbsp; will &nbsp; be &nbsp; closed &nbsp; from &nbsp; 2-10-2014 &nbsp; to &nbsp; 11-10-2014 &nbsp; for &nbsp; holy &nbsp; Eid - Ul - Azha &nbsp;.</div>', 1, '2014-08-27 05:12:21'),
(7, 'Announcement : Term  Final', '<div>Term &nbsp; Final &nbsp; Exam &nbsp; will &nbsp; start &nbsp; in &nbsp; 10-11-2014</div>', 1, '2014-08-27 05:29:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_qualification_teacher`
--

CREATE TABLE IF NOT EXISTS `tbl_qualification_teacher` (
  `qualification_id` int(7) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(6) NOT NULL,
  `degree` varchar(20) NOT NULL,
  `department` varchar(100) NOT NULL,
  `institute` varchar(200) NOT NULL,
  PRIMARY KEY (`qualification_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_qualification_teacher`
--

INSERT INTO `tbl_qualification_teacher` (`qualification_id`, `teacher_id`, `degree`, `department`, `institute`) VALUES
(8, 15, 'B.Sc.', 'Physics', 'University   of   Dhaka'),
(9, 15, 'M.B.A.', 'Business   Administration', 'University   of   Dhaka'),
(10, 17, 'B.A.', 'English', 'Jangirnagar   University'),
(11, 16, 'M.Sc.', 'Chemistry', 'University   of   Dhaka'),
(12, 16, 'B.Sc.', 'Chemistry', 'University   of   Dhaka'),
(13, 15, 'H.S.C.', 'Science', 'Udayan   Uchcha   Madhyamik   Bidydlaya'),
(14, 15, 'S.S.C.', 'Science', 'University   Laboratory   School   &   College'),
(15, 17, 'H.S.C.', 'Commerce', 'University   Laboratory   School   &   College'),
(16, 17, 'S.S.C.', 'Commerce', 'Udayan   Uchcha   Madhyamik   Bidydlaya'),
(17, 16, 'H.S.C.', 'Science', 'Udayan   Uchcha   Madhyamik   Bidydlaya'),
(18, 16, 'S.S.C.', 'Science', 'Udayan   Uchcha   Madhyamik   Bidydlaya');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE IF NOT EXISTS `tbl_student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `middle_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) NOT NULL,
  `class` int(2) NOT NULL,
  `roll` int(3) NOT NULL DEFAULT '0',
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `gender` varchar(1) NOT NULL COMMENT 'gender = m : male; gender = f : female;',
  `religion` varchar(1) NOT NULL COMMENT 'religion = i : Islam; religion = h :  Hindu; religion = c : Christian; religion = b : Buddhist; religion = o : other;',
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `student_image` varchar(100) DEFAULT NULL,
  `address` text NOT NULL,
  `registration_status` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`student_id`, `first_name`, `middle_name`, `last_name`, `class`, `roll`, `father_name`, `mother_name`, `birth_date`, `gender`, `religion`, `phone`, `email`, `password`, `student_image`, `address`, `registration_status`) VALUES
(10, 'Mahmudul', 'Hasan', 'Khan', 1, 1, 'M.   A.   Qaiyum   Khan', 'Hafiza   Khatun', '2004-12-31', 'm', 'i', '01916931410', 'cse.mahmud@yahoo.com', '7815696ecbf1c96e6894b779456d330e', 'uploads/student_images/14639_PaVeL_passport_size.JPG', 'Dhaka', 'reg'),
(11, 'Khalad', '', 'Khan', 1, 2, 'Zaman   Khan', 'Laila   Khan', '2004-12-01', 'm', 'i', '01916931410', 'khaled@mail.com', '7815696ecbf1c96e6894b779456d330e', 'uploads/student_images/14750_Arafat-Passport_Size.jpg', 'Dhaka', 'reg'),
(12, 'Krishna', '', 'Kundu', 1, 3, 'Ram  Kundu', 'Paru   Kundu', '2004-12-31', 'm', 'h', '01916931410', 'krishna@mail.com', '7815696ecbf1c96e6894b779456d330e', 'uploads/student_images/AJEET-PASSPORT-SIZE-PHOTO.jpg', 'Dhaka', 'reg'),
(13, 'Naila', '', 'Sultana', 1, 4, 'Mobatak   HUssain', 'Daizy  Ahmed', '2004-12-31', 'f', 'i', '01916931410', 'naila@mail.com', '7815696ecbf1c96e6894b779456d330e', 'uploads/student_images/110075pp.jpg', 'Dhaka', 'pen'),
(14, 'Sadia', '', 'Sahara', 1, 5, 'Alamgir  Ahmed', 'Daizy  Ahmed', '2004-12-31', 'f', 'i', '01916931410', 'sadia@mail.com', NULL, 'uploads/student_images/DSCF1090.JPG', 'Dhaka', NULL),
(15, 'Brishty', '', 'Ghosh', 1, 6, 'Arup   Ghosh', 'Shopna   Ghosh', '2004-12-31', 'f', 'h', '01916931410', 'brishty@mail.com', '7815696ecbf1c96e6894b779456d330e', 'uploads/student_images/image.jpg', 'Dhaka', 'reg'),
(16, 'Afroza', '', 'Sultana', 5, 1, 'Alim  Ali', 'Daizy  Ahmed', '2004-12-31', 'f', 'i', '01916931410', 'afroza@mail.com', '7815696ecbf1c96e6894b779456d330e', 'uploads/student_images/cc2e3b0136068080_mechristmas.sized_.jpg', 'Dhaka', 'pen'),
(17, 'Mimi', '', 'Khan', 5, 2, 'Sanowar  Khan', 'Laila   Khan', '2004-12-31', 'f', 'i', '01916931410', 'mimi@mail.com', '7815696ecbf1c96e6894b779456d330e', 'uploads/student_images/karachigirlsclub.blogspot_.com9_n_.jpg', 'Dhaka', 'reg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_switch_admission`
--

CREATE TABLE IF NOT EXISTS `tbl_switch_admission` (
  `switch_admission_id` int(1) NOT NULL AUTO_INCREMENT,
  `admission_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'admission_status = 0 : admission Off; admission_status = 1 : admission On; ',
  PRIMARY KEY (`switch_admission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_switch_admission`
--

INSERT INTO `tbl_switch_admission` (`switch_admission_id`, `admission_status`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teacher`
--

CREATE TABLE IF NOT EXISTS `tbl_teacher` (
  `teacher_id` int(6) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `middle_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) NOT NULL,
  `activity_status` tinyint(1) NOT NULL COMMENT 'activity_status = 0 : Inactive;    activity_status = 1 : Active;',
  `publication_status` tinyint(1) NOT NULL COMMENT 'publication_status = 0 : Published;   publications_status = 1 : Unpublished;',
  `teacher_image` varchar(100) DEFAULT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `gender` varchar(1) NOT NULL COMMENT 'gender = m : male; gender = f : female;',
  `religion` varchar(1) NOT NULL COMMENT 'religion = i : Islam; religion = h :  Hindu; religion = c : Christian; religion = b : Buddhist; religion = o : other;',
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_teacher`
--

INSERT INTO `tbl_teacher` (`teacher_id`, `first_name`, `middle_name`, `last_name`, `activity_status`, `publication_status`, `teacher_image`, `father_name`, `mother_name`, `birth_date`, `gender`, `religion`, `phone`, `email`, `password`, `address`) VALUES
(15, 'Zakir', '', 'Hussain', 1, 1, 'uploads/teacher_images/Passport_Size_Photo.JPG', 'Mobarak   Hussain', 'Tahlima   Banu', '1984-12-31', 'm', 'i', '01916931410', 'asd@mail.com', '7815696ecbf1c96e6894b779456d330e', 'Dhaka'),
(16, 'Razia', '', 'Sultana', 1, 1, 'uploads/teacher_images/Razia-Sultana_Passport-size-Photo.jpg', 'Sultan   Ahmed', 'Shirin  Ahmed', '1984-12-31', 'f', 'i', '01916931410', 'asd1@mail.com', '7815696ecbf1c96e6894b779456d330e', 'Dhaka'),
(17, 'Probol', 'Chandra', 'Shaha', 1, 1, 'uploads/teacher_images/dan_kutliroff_profile_picture.jpg', 'Amit  Shaha', 'Paru   Shaha', '1984-12-31', 'm', 'h', '01916931410', 'asd2@mail.com', '7815696ecbf1c96e6894b779456d330e', 'Dhaka');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
